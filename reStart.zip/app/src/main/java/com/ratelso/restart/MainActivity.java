package com.ratelso.restart;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //1. 처리할 버튼 찾기
        Button button_go = findViewById(R.id.button_go);
        //2. 버튼 클릭 시 처리 내용 세팅
        button_go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "여행하러 가는 중", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(getApplicationContext(), RussiaActivity.class);
                startActivity(intent);
            }
        });
        //3. 처리 : RussiaActivity 시작


    }
}
